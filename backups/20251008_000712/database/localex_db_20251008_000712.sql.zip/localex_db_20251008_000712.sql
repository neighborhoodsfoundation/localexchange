--
-- PostgreSQL database dump
--

\restrict ObabTt1hig6eWzQRx0gRewYPvlXsQkOXtYyaJClbwh0IBZXkSc6lZHQhrg3ctHt

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-10-08 00:07:12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 3079 OID 16717)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 5226 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 2 (class 3079 OID 16706)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5227 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 919 (class 1247 OID 16756)
-- Name: account_type; Type: TYPE; Schema: public; Owner: localex_user
--

CREATE TYPE public.account_type AS ENUM (
    'MAIN',
    'ESCROW',
    'GIFT'
);


ALTER TYPE public.account_type OWNER TO localex_user;

--
-- TOC entry 931 (class 1247 OID 16792)
-- Name: item_status; Type: TYPE; Schema: public; Owner: localex_user
--

CREATE TYPE public.item_status AS ENUM (
    'ACTIVE',
    'SOLD',
    'REMOVED',
    'DISPUTED'
);


ALTER TYPE public.item_status OWNER TO localex_user;

--
-- TOC entry 922 (class 1247 OID 16764)
-- Name: ledger_entry_type; Type: TYPE; Schema: public; Owner: localex_user
--

CREATE TYPE public.ledger_entry_type AS ENUM (
    'CREDIT',
    'DEBIT'
);


ALTER TYPE public.ledger_entry_type OWNER TO localex_user;

--
-- TOC entry 925 (class 1247 OID 16770)
-- Name: trade_status; Type: TYPE; Schema: public; Owner: localex_user
--

CREATE TYPE public.trade_status AS ENUM (
    'PENDING',
    'CONFIRMED',
    'COMPLETED',
    'CANCELLED',
    'DISPUTED'
);


ALTER TYPE public.trade_status OWNER TO localex_user;

--
-- TOC entry 928 (class 1247 OID 16782)
-- Name: user_verification_status; Type: TYPE; Schema: public; Owner: localex_user
--

CREATE TYPE public.user_verification_status AS ENUM (
    'UNVERIFIED',
    'PENDING',
    'VERIFIED',
    'REJECTED'
);


ALTER TYPE public.user_verification_status OWNER TO localex_user;

--
-- TOC entry 293 (class 1255 OID 17006)
-- Name: create_balanced_transaction(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: localex_user
--

CREATE FUNCTION public.create_balanced_transaction(transaction_uuid uuid, entries jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    entry JSONB;
    total_credits DECIMAL(12,2) := 0;
    total_debits DECIMAL(12,2) := 0;
BEGIN
    -- Validate entries structure and calculate totals
    FOR entry IN SELECT * FROM jsonb_array_elements(entries)
    LOOP
        IF entry->>'type' = 'CREDIT' THEN
            total_credits := total_credits + (entry->>'amount')::DECIMAL(12,2);
        ELSIF entry->>'type' = 'DEBIT' THEN
            total_debits := total_debits + (entry->>'amount')::DECIMAL(12,2);
        ELSE
            RAISE EXCEPTION 'Invalid entry type: %', entry->>'type';
        END IF;
    END LOOP;
    
    -- Check if transaction is balanced
    IF total_credits != total_debits THEN
        RAISE EXCEPTION 'Transaction not balanced. Credits: %, Debits: %', 
            total_credits, total_debits;
    END IF;
    
    -- Insert all entries
    FOR entry IN SELECT * FROM jsonb_array_elements(entries)
    LOOP
        INSERT INTO ledger_entries (
            transaction_id,
            account_id,
            type,
            amount,
            currency,
            description,
            metadata,
            idempotency_key
        ) VALUES (
            transaction_uuid,
            (entry->>'account_id')::UUID,
            (entry->>'type')::ledger_entry_type,
            (entry->>'amount')::DECIMAL(12,2),
            COALESCE(entry->>'currency', 'CREDITS'),
            entry->>'description',
            entry->'metadata',
            entry->>'idempotency_key'
        );
    END LOOP;
END;
$$;


ALTER FUNCTION public.create_balanced_transaction(transaction_uuid uuid, entries jsonb) OWNER TO localex_user;

--
-- TOC entry 290 (class 1255 OID 17001)
-- Name: get_account_balance(uuid); Type: FUNCTION; Schema: public; Owner: localex_user
--

CREATE FUNCTION public.get_account_balance(account_uuid uuid) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    balance DECIMAL(12,2) := 0;
BEGIN
    SELECT COALESCE(
        (SELECT SUM(amount) FROM ledger_entries 
         WHERE account_id = account_uuid AND type = 'CREDIT'), 0
    ) - COALESCE(
        (SELECT SUM(amount) FROM ledger_entries 
         WHERE account_id = account_uuid AND type = 'DEBIT'), 0
    ) INTO balance;
    
    RETURN balance;
END;
$$;


ALTER FUNCTION public.get_account_balance(account_uuid uuid) OWNER TO localex_user;

--
-- TOC entry 294 (class 1255 OID 17007)
-- Name: transfer_credits(uuid, uuid, numeric, text, uuid); Type: FUNCTION; Schema: public; Owner: localex_user
--

CREATE FUNCTION public.transfer_credits(from_account_id uuid, to_account_id uuid, amount numeric, description text, transaction_uuid uuid DEFAULT gen_random_uuid()) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_balance DECIMAL(12,2);
BEGIN
    -- Check sender balance
    current_balance := get_account_balance(from_account_id);
    
    IF current_balance < amount THEN
        RAISE EXCEPTION 'Insufficient balance. Current: %, Requested: %', 
            current_balance, amount;
    END IF;
    
    -- Create balanced transaction
    PERFORM create_balanced_transaction(
        transaction_uuid,
        jsonb_build_array(
            jsonb_build_object(
                'account_id', from_account_id,
                'type', 'DEBIT',
                'amount', amount,
                'description', description || ' (outgoing)',
                'idempotency_key', transaction_uuid || '_debit'
            ),
            jsonb_build_object(
                'account_id', to_account_id,
                'type', 'CREDIT',
                'amount', amount,
                'description', description || ' (incoming)',
                'idempotency_key', transaction_uuid || '_credit'
            )
        )
    );
    
    RETURN transaction_uuid;
END;
$$;


ALTER FUNCTION public.transfer_credits(from_account_id uuid, to_account_id uuid, amount numeric, description text, transaction_uuid uuid) OWNER TO localex_user;

--
-- TOC entry 291 (class 1255 OID 17002)
-- Name: validate_debit_balance(); Type: FUNCTION; Schema: public; Owner: localex_user
--

CREATE FUNCTION public.validate_debit_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_balance DECIMAL(12,2);
    new_balance DECIMAL(12,2);
BEGIN
    -- Only check for DEBIT entries
    IF NEW.type != 'DEBIT' THEN
        RETURN NEW;
    END IF;
    
    -- Get current balance
    current_balance := get_account_balance(NEW.account_id);
    
    -- Calculate new balance after this debit
    new_balance := current_balance - NEW.amount;
    
    -- Prevent negative balance
    IF new_balance < 0 THEN
        RAISE EXCEPTION 'Insufficient balance. Current: %, Attempted debit: %, Would result in: %', 
            current_balance, NEW.amount, new_balance;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.validate_debit_balance() OWNER TO localex_user;

--
-- TOC entry 292 (class 1255 OID 17003)
-- Name: validate_transaction_consistency(); Type: FUNCTION; Schema: public; Owner: localex_user
--

CREATE FUNCTION public.validate_transaction_consistency() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    transaction_credits DECIMAL(12,2);
    transaction_debits DECIMAL(12,2);
BEGIN
    -- Calculate total credits and debits for this transaction
    SELECT 
        COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN type = 'DEBIT' THEN amount ELSE 0 END), 0)
    INTO transaction_credits, transaction_debits
    FROM ledger_entries 
    WHERE transaction_id = NEW.transaction_id;
    
    -- Check if transaction is balanced (credits = debits)
    IF transaction_credits != transaction_debits THEN
        RAISE EXCEPTION 'Transaction not balanced. Credits: %, Debits: %', 
            transaction_credits, transaction_debits;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.validate_transaction_consistency() OWNER TO localex_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 16823)
-- Name: accounts; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.account_type DEFAULT 'MAIN'::public.account_type NOT NULL,
    updated_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.accounts OWNER TO localex_user;

--
-- TOC entry 230 (class 1259 OID 17008)
-- Name: account_balances; Type: VIEW; Schema: public; Owner: localex_user
--

CREATE VIEW public.account_balances AS
 SELECT id AS account_id,
    user_id,
    type AS account_type,
    public.get_account_balance(id) AS balance,
    created_at,
    updated_at
   FROM public.accounts a;


ALTER VIEW public.account_balances OWNER TO localex_user;

--
-- TOC entry 229 (class 1259 OID 16961)
-- Name: audit_log; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO localex_user;

--
-- TOC entry 225 (class 1259 OID 16866)
-- Name: categories; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_id uuid,
    image_url text,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.categories OWNER TO localex_user;

--
-- TOC entry 226 (class 1259 OID 16887)
-- Name: items; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    category_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    price_credits numeric(12,2) NOT NULL,
    condition character varying(50) NOT NULL,
    location_lat numeric(10,8),
    location_lng numeric(11,8),
    location_address text,
    status public.item_status DEFAULT 'ACTIVE'::public.item_status,
    is_featured boolean DEFAULT false,
    featured_until timestamp without time zone,
    view_count integer DEFAULT 0,
    cpsc_checked boolean DEFAULT false,
    cpsc_result jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT items_price_credits_check CHECK ((price_credits > (0)::numeric))
);


ALTER TABLE public.items OWNER TO localex_user;

--
-- TOC entry 224 (class 1259 OID 16842)
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.ledger_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    type public.ledger_entry_type NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'CREDITS'::character varying,
    description text NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    idempotency_key character varying(255),
    CONSTRAINT ledger_entries_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.ledger_entries OWNER TO localex_user;

--
-- TOC entry 221 (class 1259 OID 16391)
-- Name: migrations; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.migrations (
    id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    executed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.migrations OWNER TO localex_user;

--
-- TOC entry 228 (class 1259 OID 16951)
-- Name: system_settings; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.system_settings (
    key character varying(100) NOT NULL,
    value jsonb NOT NULL,
    description text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO localex_user;

--
-- TOC entry 227 (class 1259 OID 16919)
-- Name: trades; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.trades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    buyer_id uuid NOT NULL,
    price_credits numeric(12,2) NOT NULL,
    status public.trade_status DEFAULT 'PENDING'::public.trade_status,
    message text,
    meetup_location_lat numeric(10,8),
    meetup_location_lng numeric(11,8),
    meetup_location_address text,
    meetup_scheduled_at timestamp without time zone,
    confirmed_at timestamp without time zone,
    completed_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    cancelled_reason text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT trades_price_credits_check CHECK ((price_credits > (0)::numeric))
);


ALTER TABLE public.trades OWNER TO localex_user;

--
-- TOC entry 231 (class 1259 OID 17012)
-- Name: transaction_summaries; Type: VIEW; Schema: public; Owner: localex_user
--

CREATE VIEW public.transaction_summaries AS
 SELECT transaction_id,
    count(*) AS entry_count,
    sum(
        CASE
            WHEN (type = 'CREDIT'::public.ledger_entry_type) THEN amount
            ELSE (0)::numeric
        END) AS total_credits,
    sum(
        CASE
            WHEN (type = 'DEBIT'::public.ledger_entry_type) THEN amount
            ELSE (0)::numeric
        END) AS total_debits,
    min(created_at) AS transaction_date,
    string_agg(DISTINCT description, '; '::text) AS descriptions
   FROM public.ledger_entries
  GROUP BY transaction_id
  ORDER BY (min(created_at)) DESC;


ALTER VIEW public.transaction_summaries OWNER TO localex_user;

--
-- TOC entry 222 (class 1259 OID 16801)
-- Name: users; Type: TABLE; Schema: public; Owner: localex_user
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    phone character varying(20),
    date_of_birth date,
    verification_status public.user_verification_status DEFAULT 'UNVERIFIED'::public.user_verification_status,
    profile_image_url text,
    bio text,
    location_lat numeric(10,8),
    location_lng numeric(11,8),
    location_address text,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'en'::character varying,
    is_active boolean DEFAULT true,
    is_banned boolean DEFAULT false,
    last_login_at timestamp without time zone,
    email_verified_at timestamp without time zone,
    phone_verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO localex_user;

--
-- TOC entry 5213 (class 0 OID 16823)
-- Dependencies: 223
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.accounts (id, user_id, type, updated_at, created_at) FROM stdin;
ceecf715-3329-4c92-957e-754d4a1759cb	8b998b8a-b910-4d6b-9635-c3ec319cea8e	MAIN	2025-10-07 22:53:19.512811	2025-10-07 22:53:19.512811
739661b2-8885-4175-9f51-07d55b46782a	8b998b8a-b910-4d6b-9635-c3ec319cea8e	ESCROW	2025-10-07 22:53:19.512811	2025-10-07 22:53:19.512811
2d3c5058-1a37-4679-94ad-cfd4ce89a312	0ac98dc2-2c95-4ea6-b219-618a6234da81	MAIN	2025-10-07 22:53:19.650246	2025-10-07 22:53:19.650246
7bf5fe7a-9459-4edb-b95f-9f65aa21531d	0ac98dc2-2c95-4ea6-b219-618a6234da81	ESCROW	2025-10-07 22:53:19.650246	2025-10-07 22:53:19.650246
855a4fce-9871-490d-a4f9-aff2d7ce749d	c2a532b7-dcda-4d34-83f2-a37f46b3cb09	MAIN	2025-10-07 22:53:19.718177	2025-10-07 22:53:19.718177
2a214618-9c74-44a1-8c5d-73b3c84bae1e	d1c643f2-9a79-4aae-9b06-4b9c2b30de34	MAIN	2025-10-07 22:53:19.812371	2025-10-07 22:53:19.812371
26f1d18d-a074-4415-8921-aa6f58b30c3a	c6e31b52-a13d-42f8-a7c7-e94cd59923ac	MAIN	2025-10-07 22:54:40.183391	2025-10-07 22:54:40.183391
43324791-96eb-421a-8425-9bdff1c0c137	c6e31b52-a13d-42f8-a7c7-e94cd59923ac	ESCROW	2025-10-07 22:54:40.183391	2025-10-07 22:54:40.183391
a97ae143-1bb9-474a-93d7-2d90f08bf473	14695447-3e46-4be0-a126-f0973e066acc	MAIN	2025-10-07 22:54:40.318904	2025-10-07 22:54:40.318904
9ec452d8-be50-47d3-85db-8a8666ec390e	14695447-3e46-4be0-a126-f0973e066acc	ESCROW	2025-10-07 22:54:40.318904	2025-10-07 22:54:40.318904
0b3e5f18-f34e-4b8a-a337-b7e51cb6eb6e	64ef4a46-b7bf-4da3-bb57-475e6a789c63	MAIN	2025-10-07 22:54:40.382675	2025-10-07 22:54:40.382675
a8752cfe-3597-477c-a56c-3b2e1cb8b1b6	ca5b563c-02d4-428d-a5a6-5a39ec843a39	MAIN	2025-10-07 22:54:40.558964	2025-10-07 22:54:40.558964
\.


--
-- TOC entry 5219 (class 0 OID 16961)
-- Dependencies: 229
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.audit_log (id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- TOC entry 5215 (class 0 OID 16866)
-- Dependencies: 225
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.categories (id, name, description, parent_id, image_url, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5216 (class 0 OID 16887)
-- Dependencies: 226
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.items (id, user_id, category_id, title, description, price_credits, condition, location_lat, location_lng, location_address, status, is_featured, featured_until, view_count, cpsc_checked, cpsc_result, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5214 (class 0 OID 16842)
-- Dependencies: 224
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.ledger_entries (id, account_id, transaction_id, type, amount, currency, description, metadata, created_at, idempotency_key) FROM stdin;
\.


--
-- TOC entry 5211 (class 0 OID 16391)
-- Dependencies: 221
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.migrations (id, filename, executed_at) FROM stdin;
001_simple_schema	001_simple_schema.sql	2025-10-07 22:45:41.053095
002_balance_triggers	002_balance_triggers.sql	2025-10-07 22:51:50.094225
\.


--
-- TOC entry 5218 (class 0 OID 16951)
-- Dependencies: 228
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.system_settings (key, value, description, updated_at) FROM stdin;
\.


--
-- TOC entry 5217 (class 0 OID 16919)
-- Dependencies: 227
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.trades (id, item_id, seller_id, buyer_id, price_credits, status, message, meetup_location_lat, meetup_location_lng, meetup_location_address, meetup_scheduled_at, confirmed_at, completed_at, cancelled_at, cancelled_reason, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5212 (class 0 OID 16801)
-- Dependencies: 222
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: localex_user
--

COPY public.users (id, email, password_hash, first_name, last_name, phone, date_of_birth, verification_status, profile_image_url, bio, location_lat, location_lng, location_address, timezone, language, is_active, is_banned, last_login_at, email_verified_at, phone_verified_at, created_at, updated_at) FROM stdin;
8b998b8a-b910-4d6b-9635-c3ec319cea8e	test@example.com	hash	Test	User	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:53:19.508583	2025-10-07 22:53:19.508583
0ac98dc2-2c95-4ea6-b219-618a6234da81	test3@example.com	hash	Test	User	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:53:19.64931	2025-10-07 22:53:19.64931
c2a532b7-dcda-4d34-83f2-a37f46b3cb09	perf@example.com	hash	Perf	Test	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:53:19.715117	2025-10-07 22:53:19.715117
d1c643f2-9a79-4aae-9b06-4b9c2b30de34	balance@example.com	hash	Balance	Test	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:53:19.810116	2025-10-07 22:53:19.810116
c6e31b52-a13d-42f8-a7c7-e94cd59923ac	test-1759895680179@example.com	hash	Test	User	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:54:40.18084	2025-10-07 22:54:40.18084
14695447-3e46-4be0-a126-f0973e066acc	test3-1759895680317@example.com	hash	Test	User	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:54:40.318038	2025-10-07 22:54:40.318038
64ef4a46-b7bf-4da3-bb57-475e6a789c63	perf-1759895680320@example.com	hash	Perf	Test	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:54:40.380155	2025-10-07 22:54:40.380155
ca5b563c-02d4-428d-a5a6-5a39ec843a39	balance-1759895680556@example.com	hash	Balance	Test	\N	\N	UNVERIFIED	\N	\N	\N	\N	\N	UTC	en	t	f	\N	\N	\N	2025-10-07 22:54:40.556326	2025-10-07 22:54:40.556326
\.


--
-- TOC entry 5013 (class 2606 OID 16834)
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 5015 (class 2606 OID 16836)
-- Name: accounts accounts_user_id_type_key; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_type_key UNIQUE (user_id, type);


--
-- TOC entry 5047 (class 2606 OID 16973)
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 5027 (class 2606 OID 16881)
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- TOC entry 5029 (class 2606 OID 16879)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 5036 (class 2606 OID 16908)
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- TOC entry 5023 (class 2606 OID 16860)
-- Name: ledger_entries ledger_entries_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_idempotency_key_key UNIQUE (idempotency_key);


--
-- TOC entry 5025 (class 2606 OID 16858)
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 5004 (class 2606 OID 16400)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 5045 (class 2606 OID 16960)
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- TOC entry 5043 (class 2606 OID 16935)
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- TOC entry 5009 (class 2606 OID 16822)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 5011 (class 2606 OID 16820)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 5016 (class 1259 OID 16983)
-- Name: idx_accounts_type; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_accounts_type ON public.accounts USING btree (type);


--
-- TOC entry 5017 (class 1259 OID 16982)
-- Name: idx_accounts_user_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_accounts_user_id ON public.accounts USING btree (user_id);


--
-- TOC entry 5048 (class 1259 OID 17000)
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- TOC entry 5049 (class 1259 OID 16999)
-- Name: idx_audit_log_entity; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id);


--
-- TOC entry 5050 (class 1259 OID 16998)
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- TOC entry 5030 (class 1259 OID 16989)
-- Name: idx_items_category_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_items_category_id ON public.items USING btree (category_id);


--
-- TOC entry 5031 (class 1259 OID 16992)
-- Name: idx_items_created_at; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_items_created_at ON public.items USING btree (created_at);


--
-- TOC entry 5032 (class 1259 OID 16991)
-- Name: idx_items_price; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_items_price ON public.items USING btree (price_credits);


--
-- TOC entry 5033 (class 1259 OID 16990)
-- Name: idx_items_status; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_items_status ON public.items USING btree (status);


--
-- TOC entry 5034 (class 1259 OID 16988)
-- Name: idx_items_user_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_items_user_id ON public.items USING btree (user_id);


--
-- TOC entry 5018 (class 1259 OID 16984)
-- Name: idx_ledger_entries_account_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_ledger_entries_account_id ON public.ledger_entries USING btree (account_id);


--
-- TOC entry 5019 (class 1259 OID 16986)
-- Name: idx_ledger_entries_created_at; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_ledger_entries_created_at ON public.ledger_entries USING btree (created_at);


--
-- TOC entry 5020 (class 1259 OID 16987)
-- Name: idx_ledger_entries_idempotency_key; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_ledger_entries_idempotency_key ON public.ledger_entries USING btree (idempotency_key);


--
-- TOC entry 5021 (class 1259 OID 16985)
-- Name: idx_ledger_entries_transaction_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_ledger_entries_transaction_id ON public.ledger_entries USING btree (transaction_id);


--
-- TOC entry 5037 (class 1259 OID 16995)
-- Name: idx_trades_buyer_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_trades_buyer_id ON public.trades USING btree (buyer_id);


--
-- TOC entry 5038 (class 1259 OID 16997)
-- Name: idx_trades_created_at; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_trades_created_at ON public.trades USING btree (created_at);


--
-- TOC entry 5039 (class 1259 OID 16993)
-- Name: idx_trades_item_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_trades_item_id ON public.trades USING btree (item_id);


--
-- TOC entry 5040 (class 1259 OID 16994)
-- Name: idx_trades_seller_id; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_trades_seller_id ON public.trades USING btree (seller_id);


--
-- TOC entry 5041 (class 1259 OID 16996)
-- Name: idx_trades_status; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_trades_status ON public.trades USING btree (status);


--
-- TOC entry 5005 (class 1259 OID 16981)
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- TOC entry 5006 (class 1259 OID 16979)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 5007 (class 1259 OID 16980)
-- Name: idx_users_verification_status; Type: INDEX; Schema: public; Owner: localex_user
--

CREATE INDEX idx_users_verification_status ON public.users USING btree (verification_status);


--
-- TOC entry 5060 (class 2620 OID 17004)
-- Name: ledger_entries trigger_validate_debit_balance; Type: TRIGGER; Schema: public; Owner: localex_user
--

CREATE TRIGGER trigger_validate_debit_balance BEFORE INSERT ON public.ledger_entries FOR EACH ROW EXECUTE FUNCTION public.validate_debit_balance();


--
-- TOC entry 5061 (class 2620 OID 17005)
-- Name: ledger_entries trigger_validate_transaction_consistency; Type: TRIGGER; Schema: public; Owner: localex_user
--

CREATE TRIGGER trigger_validate_transaction_consistency AFTER INSERT ON public.ledger_entries FOR EACH ROW EXECUTE FUNCTION public.validate_transaction_consistency();


--
-- TOC entry 5051 (class 2606 OID 16837)
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5059 (class 2606 OID 16974)
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 5053 (class 2606 OID 16882)
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- TOC entry 5054 (class 2606 OID 16914)
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- TOC entry 5055 (class 2606 OID 16909)
-- Name: items items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5052 (class 2606 OID 16861)
-- Name: ledger_entries ledger_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- TOC entry 5056 (class 2606 OID 16946)
-- Name: trades trades_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5057 (class 2606 OID 16936)
-- Name: trades trades_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- TOC entry 5058 (class 2606 OID 16941)
-- Name: trades trades_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: localex_user
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5225 (class 0 OID 0)
-- Dependencies: 7
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO localex_user;


--
-- TOC entry 2160 (class 826 OID 16390)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO localex_user;


-- Completed on 2025-10-08 00:07:12

--
-- PostgreSQL database dump complete
--

\unrestrict ObabTt1hig6eWzQRx0gRewYPvlXsQkOXtYyaJClbwh0IBZXkSc6lZHQhrg3ctHt

